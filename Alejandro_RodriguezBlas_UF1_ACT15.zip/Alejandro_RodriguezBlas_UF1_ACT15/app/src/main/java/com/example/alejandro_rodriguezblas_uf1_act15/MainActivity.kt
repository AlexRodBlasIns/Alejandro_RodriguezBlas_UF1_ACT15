package com.example.alejandro_rodriguezblas_uf1_act15

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var button0: Button
    lateinit var button1: Button
    lateinit var button2: Button
    lateinit var button3: Button
    lateinit var button4: Button
    lateinit var button5: Button
    lateinit var button6: Button
    lateinit var button7: Button
    lateinit var button8: Button
    lateinit var button9: Button
    lateinit var buttonPlus: Button
    lateinit var buttonLess: Button
    lateinit var buttonMult: Button
    lateinit var buttonDiv: Button
    lateinit var buttonEquals: Button

    lateinit var text: TextView

    var numIzq : Int = 0
    var operacion: Int = 0
    var numDer: Int = 0
    var res: Float = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        text = findViewById(R.id.texto)
        button0 = findViewById(R.id.button0)
        button1 = findViewById(R.id.button1)
        button2 = findViewById(R.id.button2)
        button3 = findViewById(R.id.button3)
        button4 = findViewById(R.id.button4)
        button5 = findViewById(R.id.button5)
        button6 = findViewById(R.id.button6)
        button7 = findViewById(R.id.button7)
        button8 = findViewById(R.id.button8)
        button9 = findViewById(R.id.button9)
        buttonPlus = findViewById(R.id.buttonPlus)
        buttonLess = findViewById(R.id.buttonLess)
        buttonDiv = findViewById(R.id.buttonDiv)
        buttonMult = findViewById(R.id.buttonMult)
        buttonEquals = findViewById(R.id.buttonEquals)

        text.text = ""
        button0.setOnClickListener {
            BotonNumPulsado(0)
        }
        button1.setOnClickListener {
            BotonNumPulsado(1)
        }
        button2.setOnClickListener {
            BotonNumPulsado(2)
        }
        button3.setOnClickListener {
            BotonNumPulsado(3)
        }
        button4.setOnClickListener {
            BotonNumPulsado(4)
        }
        button5.setOnClickListener {
            BotonNumPulsado(5)
        }
        button6.setOnClickListener {
            BotonNumPulsado(6)
        }
        button7.setOnClickListener {
            BotonNumPulsado(7)
        }
        button8.setOnClickListener {
            BotonNumPulsado(8)
        }
        button9.setOnClickListener {
            BotonNumPulsado(9)
        }
        buttonPlus.setOnClickListener {
            BotonOperacionPulsado(1)
        }
        buttonLess.setOnClickListener {
            BotonOperacionPulsado(2)
        }
        buttonMult.setOnClickListener {
            BotonOperacionPulsado(3)
        }
        buttonDiv.setOnClickListener {
            BotonOperacionPulsado(4)
        }
        buttonEquals.setOnClickListener {
            operar()
        }

    }

    fun BotonNumPulsado(num: Int){

        if(res != 0f){
            text.text = ""
            res = 0f
        }
        if(operacion == 0){
            numIzq = (numIzq*10)+num
        }
        else {
            numDer = (numDer*10) + num
        }

        text.append(num.toString())
    }

    fun BotonOperacionPulsado(operacion:Int){
        if(this.operacion == 0) {

            this.operacion = operacion

            when (operacion) {
                1 -> {
                    text.append("+")
                }
                2 -> {
                    text.append("-")
                }
                3 -> {
                    text.append("x")
                }
                else -> {
                    text.append("/")
                }
            }
        }

    }

    fun operar(){

        when(operacion){
            1 -> {
                res = (numIzq+numDer.toFloat())
            }
            2 ->{
                res = (numIzq-numDer.toFloat())
            }
            3 ->{
                res = (numIzq*numDer.toFloat())
            }
            4 ->{
                res = (numIzq/numDer.toFloat())
            }
        }
        text.text = res.toString()
        numIzq = 0
        numDer = 0
        operacion = 0
    }
}